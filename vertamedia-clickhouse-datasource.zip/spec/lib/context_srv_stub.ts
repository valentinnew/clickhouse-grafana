export default class ContextSrvStub {
  hasRole() {
    return true;
  }
}
