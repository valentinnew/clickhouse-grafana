import { RawTimeRange } from '../../src/sql_query';

export const RawTimeRangeStub: RawTimeRange = {} as RawTimeRange;
